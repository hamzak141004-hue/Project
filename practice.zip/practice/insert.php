<?php
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];

    $sql = "INSERT INTO students (name, email) VALUES ('$name', '$email')";
    if ($conn->query($sql)) {
        header("Location: index.php"); // redirect to main page
    } else {
        echo "Error: " . $conn->error;
    }
}
?>
